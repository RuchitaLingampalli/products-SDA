import { Component, OnInit } from '@angular/core';
import { ProductsService, Products } from '../products.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  product: ProductsService;
  pro: Products;

  constructor(product: ProductsService) {
    this.product = product;
   }
 
  ngOnInit() {
  }
  add(data: any)
  {
    this.pro = new Products(data.id, data.name, data.category);
    this.product.addData(this.pro);
  }
}
