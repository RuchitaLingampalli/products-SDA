import { Component, OnInit } from '@angular/core';
import { ProductsService, Products } from '../products.service';

@Component({
  selector: 'app-showproduct',
  templateUrl: './showproduct.component.html',
  styleUrls: ['./showproduct.component.css']
})
export class ShowproductComponent implements OnInit {
product:ProductsService;

dept:Products[]=[];

  constructor(product:ProductsService) {
    this.product=product;
   }
   delete(p){
    let index=this.dept.indexOf(p);
    this.dept.splice(index,1);
  }

  ngOnInit() {
    this.product.fetchData();
    this.dept=this.product.getData();
  }

}
