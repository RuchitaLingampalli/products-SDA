
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  http: HttpClient;
  fetch: boolean = false;
  prod : Products[] = [];
  constructor(http: HttpClient) {
    this.http = http;
   }

   fetchData(){
     this.http.get('./assets/products.json').subscribe(
       data =>{
         if(!this.fetch){
           this.convert(data);
           this.fetch = true;
         }
       }
     )
   }
   convert(data: any){
     for(let pro of data){
       let p = new Products(pro.id, pro.name, pro.category);
       this.prod.push(p);
     }
   }
   getData(): Products[]{
    return this.prod;
   }

   addData(p : any){
    this.prod.push(p);
    }
    updatedata(d:Products){
      let eid=d.id;
      for(let i=0;i<this.prod.length;i++){
        if(eid==this.prod[i].id){
          this.prod[i].id=d.id;
          this.prod[i].name=d.name;
          this.prod[i].category=d.category;
        }
      }
  }
}
    export class Products{
      
      id: number;
      name: string;
     category: string;
      constructor(id:number,name:string, category:string){
        this.id = id;
        this.name = name;
        this.category = category;
      }
    }


